no addon folder anywhere
